# BV Portal Backend

API backend du portail de gestion des **bureaux de vente (BV)**, construite avec **Spring Boot 3.5 / Java 21**.

Stack : Spring Security (cookies HttpOnly + JWT avec rotation), Redis (blacklist de tokens), PostgreSQL + Flyway, RBAC (rôles/permissions), validation Bean Validation, documentation Swagger/OpenAPI.

---

## 1. Diagramme de classe (domaine)

```mermaid
classDiagram
    class Region {
        +Long id
        +String name
    }

    class Ville {
        +Long id
        +String name
    }

    class Quartier {
        +Long id
        +String name
    }

    class BureauVente {
        +Long id
        +String name
        +String code
        +boolean active
    }

    class User {
        +Long id
        +String email
        +String username
        +String password
        +boolean enabled
    }

    class Role {
        +Long id
        +String name
    }

    class Permission {
        +Long id
        +String name
    }

    Region "1" --> "0..*" Ville : contient
    Ville "1" --> "0..*" Quartier : contient
    Quartier "1" --> "0..*" BureauVente : contient
    Region "1" --> "0..*" User : gérée par
    User "0..*" --> "0..*" Role : possède
    Role "0..*" --> "0..*" Permission : accorde
```

**Règle métier clé** : un `User` est rattaché à une `Region` et gère, de fait, tous les `BureauVente` de cette région (via la chaîne `Region -> Ville -> Quartier -> BureauVente`). Aucune table de liaison directe `User <-> BureauVente` n'est nécessaire : l'appartenance géographique suffit.

---

## 2. Authentification - JWT en cookies HttpOnly + rotation + blacklist Redis

- À la connexion (`/auth/login`), deux JWT sont émis : un **access token** (courte durée, 15 min par défaut) et un **refresh token** (longue durée, 7 jours par défaut). Chaque token possède un identifiant unique (`jti`).
- Les deux tokens sont posés en **cookies `HttpOnly`, `Secure` (en prod), `SameSite`** — jamais renvoyés dans le corps JSON de la réponse, pour limiter l'exposition aux attaques XSS.
- **Rotation** : à chaque appel à `/auth/refresh`, l'ancien `refresh_token` est immédiatement blacklisté dans Redis (clé `blacklist:jti:<jti>`, TTL = durée de vie restante du token) et une nouvelle paire access/refresh est émise. Un refresh token ne peut donc être utilisé qu'une seule fois.
- **Logout** : `access_token` et `refresh_token` courants sont blacklistés immédiatement (révocation avant expiration), puis les cookies sont effacés.
- Le filtre `JwtAuthenticationFilter` lit le cookie `access_token`, vérifie la signature, le type (`ACCESS`), l'expiration et l'absence de blacklist, puis construit le contexte de sécurité directement depuis les claims du token (rôles + permissions), sans accès base à chaque requête (stateless).

## 3. RBAC

- `users` ↔ `roles` (many-to-many) et `roles` ↔ `permissions` (many-to-many).
- Les autorités Spring Security exposées sont : `ROLE_<NOM_DU_ROLE>` (pour `hasRole`) et le nom brut de chaque permission, ex. `BV_READ`, `BV_MANAGE`, `GEO_MANAGE` (pour `hasAuthority`).
- Données initiales (`V2__seed_rbac.sql`) : `ROLE_ADMIN` (toutes permissions) et `ROLE_USER` (`BV_READ`, `BV_MANAGE`).

## 4. Endpoints principaux

### Authentification (`/api/v1/auth`)
| Méthode | Endpoint | Description | Accès |
|---|---|---|---|
| POST | `/register` | Créer un compte (email, username, password ; region/roles facultatifs) | public |
| POST | `/login` | Connexion, pose les cookies | public |
| POST | `/refresh` | Rotation des tokens (lit le cookie `refresh_token`) | public (token requis) |
| POST | `/logout` | Déconnexion, blackliste + efface les cookies | public (token requis) |

### Espace utilisateur connecté (`/api/v1/me`) — pour le portail web
| Méthode | Endpoint | Description |
|---|---|---|
| GET | `/me` | Profil de l'utilisateur connecté |
| GET | `/me/villes` | Villes de la région de l'utilisateur (1er niveau de filtre) |
| GET | `/me/quartiers?villeId=` | Quartiers de la région, filtrables par ville (2e niveau de filtre) |
| GET | `/me/bureaux-vente?villeId=&quartierId=` | BV de l'utilisateur : **sélection directe** (sans paramètre) ou filtrée par ville/quartier |

Toute tentative de filtrer avec un `villeId`/`quartierId` n'appartenant pas à la région de l'utilisateur renvoie `403 Forbidden` (vérifié côté serveur, pas seulement côté front).

### Référentiels géographiques (administration)
| Méthode | Endpoint | Accès |
|---|---|---|
| GET `/api/v1/regions` | toute personne authentifiée |
| POST `/api/v1/regions` | permission `GEO_MANAGE` (ROLE_ADMIN) |
| GET `/api/v1/villes?regionId=` | authentifié |
| POST `/api/v1/villes` | `GEO_MANAGE` |
| GET `/api/v1/quartiers?villeId=` | authentifié |
| POST `/api/v1/quartiers` | `GEO_MANAGE` |
| GET `/api/v1/bureaux-vente?quartierId=` | authentifié |
| POST `/api/v1/bureaux-vente` | `GEO_MANAGE` |

## 5. Démarrage local

```bash
# 1. Lancer PostgreSQL + Redis
docker compose up -d

# 2. Lancer l'application (Flyway exécute les migrations automatiquement)
./mvnw spring-boot:run
```

Swagger UI : http://localhost:8080/swagger-ui.html

### Variables d'environnement (valeurs par défaut en local, à surcharger en prod)
| Variable | Description |
|---|---|
| `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` | Connexion PostgreSQL |
| `REDIS_HOST`, `REDIS_PORT`, `REDIS_PASSWORD` | Connexion Redis |
| `JWT_SECRET` | Clé HMAC, encodée en Base64 (≥ 32 octets décodés) — **à changer en production** |
| `JWT_ACCESS_TTL`, `JWT_REFRESH_TTL` | Durées de vie (minutes / jours) |
| `COOKIE_SECURE` | `true` en production (HTTPS obligatoire) |
| `COOKIE_SAME_SITE` | `Lax`, `Strict` ou `None` |
| `CORS_ALLOWED_ORIGINS` | Origines autorisées (le front du portail) |

## 6. Exemple de flux (curl, avec gestion des cookies)

```bash
# Inscription
curl -X POST http://localhost:8080/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"jean.dupont@example.com","username":"jdupont","password":"MotDePasse123!"}'

# Connexion (sauvegarde les cookies)
curl -c cookies.txt -X POST http://localhost:8080/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"usernameOrEmail":"jdupont","password":"MotDePasse123!"}'

# Appel authentifié via cookie
curl -b cookies.txt http://localhost:8080/api/v1/me

# Rafraîchissement (rotation)
curl -b cookies.txt -c cookies.txt -X POST http://localhost:8080/api/v1/auth/refresh

# Déconnexion
curl -b cookies.txt -X POST http://localhost:8080/api/v1/auth/logout
```

## 7. Notes de conception (light version, sans surcomplexité)

- Pas de MapStruct : mappers manuels simples (`GeoMapper`, `UserMapper`).
- Pas de DTO d'update séparé pour les référentiels géographiques : uniquement création + lecture (suffisant pour alimenter les sélecteurs front).
- Le contexte de sécurité est reconstruit depuis les claims du token (roles/permissions), pas via une requête base à chaque appel — sauf pour `/me/*`, qui a besoin de récupérer la région actuelle de l'utilisateur en base.
- `RegisterRequest` est volontairement réduit à `email`, `username`, `password` ; `regionId` et `roles` sont facultatifs (rôle `ROLE_USER` appliqué par défaut).
