package com.bvportal.backend.security;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class JwtServiceTest {

    private final JwtProperties properties = new JwtProperties(
            "c2VjcmV0LWNsZS1kZXYtdW5pcXVlbWVudC1wb3VyLWxlLWRldmVsb3BwZW1lbnQtMzItYnl0ZXMtbWluaW11bQ==",
            15,
            7,
            "bv-portal-test"
    );

    private final JwtService jwtService = new JwtService(properties);

    @Test
    void generatesAndParsesAccessToken() {
        var token = jwtService.generateAccessToken(1L, "jdupont", List.of("ROLE_USER"), List.of("BV_READ"));

        var claims = jwtService.parseClaims(token.token());

        assertEquals("jdupont", claims.getSubject());
        assertEquals(token.jti(), claims.getId());
        assertEquals(TokenType.ACCESS, jwtService.extractType(claims));
        assertEquals(1L, jwtService.extractUserId(claims));
        assertTrue(jwtService.extractRoles(claims).contains("ROLE_USER"));
        assertTrue(jwtService.extractPermissions(claims).contains("BV_READ"));
        assertFalse(jwtService.isExpired(claims));
    }

    @Test
    void generatesRefreshTokenWithoutRolesOrPermissions() {
        var token = jwtService.generateRefreshToken(42L, "jdupont");
        var claims = jwtService.parseClaims(token.token());

        assertEquals(TokenType.REFRESH, jwtService.extractType(claims));
        assertEquals(42L, jwtService.extractUserId(claims));
        assertTrue(jwtService.extractRoles(claims).isEmpty());
    }
}
