-- ===================================================================
-- Données de référence : permissions et rôles par défaut
-- ===================================================================

INSERT INTO permissions (name, description) VALUES
    ('BV_READ',        'Consulter les bureaux de vente'),
    ('BV_MANAGE',      'Gérer (créer/modifier) les bureaux de vente'),
    ('GEO_MANAGE',     'Gérer régions, villes et quartiers'),
    ('USER_MANAGE',    'Gérer les utilisateurs');

INSERT INTO roles (name, description) VALUES
    ('ROLE_ADMIN', 'Administrateur - accès complet'),
    ('ROLE_USER',  'Utilisateur standard - gère les BV de sa région');

-- ROLE_ADMIN -> toutes les permissions
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p WHERE r.name = 'ROLE_ADMIN';

-- ROLE_USER -> lecture/gestion BV uniquement
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.name IN ('BV_READ', 'BV_MANAGE')
WHERE r.name = 'ROLE_USER';
