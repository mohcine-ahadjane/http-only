package com.bvportal.backend.mapper;

import com.bvportal.backend.domain.entity.Role;
import com.bvportal.backend.domain.entity.User;
import com.bvportal.backend.dto.response.UserResponse;

import java.util.stream.Collectors;

public final class UserMapper {

    private UserMapper() {
    }

    public static UserResponse toResponse(User user) {
        return new UserResponse(
                user.getId(),
                user.getEmail(),
                user.getUsername(),
                user.isEnabled(),
                user.getRegion() != null ? GeoMapper.toResponse(user.getRegion()) : null,
                user.getRoles().stream().map(Role::getName).collect(Collectors.toUnmodifiableSet())
        );
    }
}
