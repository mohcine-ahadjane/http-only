package com.bvportal.backend.dto.response;

import java.util.Set;

public record UserResponse(
        Long id,
        String email,
        String username,
        boolean enabled,
        RegionResponse region,
        Set<String> roles
) {
}
