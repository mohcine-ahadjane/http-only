package com.bvportal.backend.controller;

import com.bvportal.backend.dto.request.BureauVenteCreateRequest;
import com.bvportal.backend.dto.response.BureauVenteResponse;
import com.bvportal.backend.mapper.GeoMapper;
import com.bvportal.backend.service.GeoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/bureaux-vente")
@RequiredArgsConstructor
@Tag(name = "Bureaux de vente", description = "Référentiel géographique - bureaux de vente (BV)")
public class BureauVenteController {

    private final GeoService geoService;

    @GetMapping
    @Operation(summary = "Lister les bureaux de vente d'un quartier (quartierId obligatoire)")
    public List<BureauVenteResponse> findByQuartier(@RequestParam Long quartierId) {
        return geoService.findBureauxByQuartier(quartierId).stream().map(GeoMapper::toResponse).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('GEO_MANAGE')")
    @Operation(summary = "Créer un bureau de vente")
    public BureauVenteResponse create(@Valid @RequestBody BureauVenteCreateRequest request) {
        return GeoMapper.toResponse(geoService.createBureauVente(request));
    }
}
