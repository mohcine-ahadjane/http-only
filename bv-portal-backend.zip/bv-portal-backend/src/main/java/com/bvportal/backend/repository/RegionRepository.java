package com.bvportal.backend.repository;

import com.bvportal.backend.domain.entity.Region;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RegionRepository extends JpaRepository<Region, Long> {
    boolean existsByNameIgnoreCase(String name);
    Optional<Region> findByNameIgnoreCase(String name);
}
