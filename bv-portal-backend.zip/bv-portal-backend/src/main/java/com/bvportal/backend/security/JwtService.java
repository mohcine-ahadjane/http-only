package com.bvportal.backend.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class JwtService {

    private static final String CLAIM_TYPE = "type";
    private static final String CLAIM_USER_ID = "uid";
    private static final String CLAIM_ROLES = "roles";
    private static final String CLAIM_PERMISSIONS = "permissions";

    private final JwtProperties jwtProperties;

    private SecretKey signingKey() {
        byte[] keyBytes = Base64.getDecoder().decode(jwtProperties.secret());
        return Keys.hmacShaKeyFor(keyBytes);
    }

    public GeneratedToken generateAccessToken(Long userId, String username, List<String> roles, List<String> permissions) {
        Instant now = Instant.now();
        Instant expiresAt = now.plus(jwtProperties.accessTokenTtlMinutes(), ChronoUnit.MINUTES);
        String jti = UUID.randomUUID().toString();

        String token = Jwts.builder()
                .subject(username)
                .id(jti)
                .issuer(jwtProperties.issuer())
                .issuedAt(java.util.Date.from(now))
                .expiration(java.util.Date.from(expiresAt))
                .claim(CLAIM_TYPE, TokenType.ACCESS.name())
                .claim(CLAIM_USER_ID, String.valueOf(userId))
                .claim(CLAIM_ROLES, roles)
                .claim(CLAIM_PERMISSIONS, permissions)
                .signWith(signingKey())
                .compact();

        return new GeneratedToken(token, jti, expiresAt);
    }

    public GeneratedToken generateRefreshToken(Long userId, String username) {
        Instant now = Instant.now();
        Instant expiresAt = now.plus(jwtProperties.refreshTokenTtlDays(), ChronoUnit.DAYS);
        String jti = UUID.randomUUID().toString();

        String token = Jwts.builder()
                .subject(username)
                .id(jti)
                .issuer(jwtProperties.issuer())
                .issuedAt(java.util.Date.from(now))
                .expiration(java.util.Date.from(expiresAt))
                .claim(CLAIM_TYPE, TokenType.REFRESH.name())
                .claim(CLAIM_USER_ID, String.valueOf(userId))
                .signWith(signingKey())
                .compact();

        return new GeneratedToken(token, jti, expiresAt);
    }

    /**
     * Parse et valide la signature/l'expiration du token.
     * Lève une JwtException (ou sous-classe) si le token est invalide/expiré.
     */
    public Claims parseClaims(String token) {
        return Jwts.parser()
                .verifyWith(signingKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public boolean isExpired(Claims claims) {
        return claims.getExpiration().toInstant().isBefore(Instant.now());
    }

    public TokenType extractType(Claims claims) {
        return TokenType.valueOf(claims.get(CLAIM_TYPE, String.class));
    }

    public Long extractUserId(Claims claims) {
        String value = claims.get(CLAIM_USER_ID, String.class);
        return value == null ? null : Long.parseLong(value);
    }

    @SuppressWarnings("unchecked")
    public List<String> extractRoles(Claims claims) {
        Object value = claims.get(CLAIM_ROLES);
        return value == null ? List.of() : (List<String>) value;
    }

    @SuppressWarnings("unchecked")
    public List<String> extractPermissions(Claims claims) {
        Object value = claims.get(CLAIM_PERMISSIONS);
        return value == null ? List.of() : (List<String>) value;
    }
}
