package com.bvportal.backend.service;

import com.bvportal.backend.domain.entity.BureauVente;
import com.bvportal.backend.domain.entity.Quartier;
import com.bvportal.backend.domain.entity.User;
import com.bvportal.backend.domain.entity.Ville;
import com.bvportal.backend.exception.ForbiddenOperationException;
import com.bvportal.backend.exception.ResourceNotFoundException;
import com.bvportal.backend.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class MeService {

    private final UserRepository userRepository;
    private final GeoService geoService;

    public User getCurrentUserEntity(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Utilisateur introuvable, id=" + userId));
    }

    /** Villes de la région gérée par l'utilisateur connecté. */
    public List<Ville> getMyVilles(Long userId) {
        Long regionId = requireRegionId(userId);
        return geoService.findVillesByRegion(regionId);
    }

    /**
     * Quartiers de la région de l'utilisateur, filtrés optionnellement par ville.
     * Si villeId est fourni, on vérifie qu'elle appartient bien à la région de l'utilisateur.
     */
    public List<Quartier> getMyQuartiers(Long userId, Long villeId) {
        Long regionId = requireRegionId(userId);

        if (villeId == null) {
            return geoService.findQuartiersByRegion(regionId);
        }

        if (!geoService.villeBelongsToRegion(villeId, regionId)) {
            throw new ForbiddenOperationException("Cette ville n'appartient pas à votre région");
        }
        return geoService.findQuartiersByVille(villeId);
    }

    /**
     * Bureaux de vente de la région de l'utilisateur. Supporte :
     *  - sélection directe (aucun filtre) -> tous les BV de la région
     *  - filtre par quartierId (après avoir choisi ville puis quartier)
     *  - filtre par villeId (tous les BV de toutes les quartiers de cette ville)
     */
    public List<BureauVente> getMyBureauxVente(Long userId, Long villeId, Long quartierId) {
        Long regionId = requireRegionId(userId);

        if (quartierId != null) {
            if (!geoService.quartierBelongsToRegion(quartierId, regionId)) {
                throw new ForbiddenOperationException("Ce quartier n'appartient pas à votre région");
            }
            if (villeId != null && !geoService.quartierBelongsToVille(quartierId, villeId)) {
                throw new ForbiddenOperationException("Ce quartier n'appartient pas à la ville indiquée");
            }
            return geoService.findBureauxByQuartier(quartierId);
        }

        if (villeId != null) {
            if (!geoService.villeBelongsToRegion(villeId, regionId)) {
                throw new ForbiddenOperationException("Cette ville n'appartient pas à votre région");
            }
            return geoService.findBureauxByVille(villeId);
        }

        // Sélection directe : tous les BV de la région de l'utilisateur
        return geoService.findBureauxByRegion(regionId);
    }

    private Long requireRegionId(Long userId) {
        User user = getCurrentUserEntity(userId);
        if (user.getRegion() == null) {
            throw new ForbiddenOperationException("Aucune région n'est assignée à votre compte");
        }
        return user.getRegion().getId();
    }
}
