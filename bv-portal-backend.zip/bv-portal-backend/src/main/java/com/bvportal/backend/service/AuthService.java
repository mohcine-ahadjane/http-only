package com.bvportal.backend.service;

import com.bvportal.backend.domain.entity.Region;
import com.bvportal.backend.domain.entity.Role;
import com.bvportal.backend.domain.entity.User;
import com.bvportal.backend.dto.request.LoginRequest;
import com.bvportal.backend.dto.request.RegisterRequest;
import com.bvportal.backend.exception.DuplicateResourceException;
import com.bvportal.backend.exception.InvalidTokenException;
import com.bvportal.backend.exception.ResourceNotFoundException;
import com.bvportal.backend.repository.RegionRepository;
import com.bvportal.backend.repository.RoleRepository;
import com.bvportal.backend.repository.UserRepository;
import com.bvportal.backend.security.GeneratedToken;
import com.bvportal.backend.security.JwtService;
import com.bvportal.backend.security.TokenBlacklistService;
import com.bvportal.backend.security.TokenPair;
import com.bvportal.backend.security.TokenType;
import com.bvportal.backend.security.UserPrincipal;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class AuthService {

    private static final String DEFAULT_ROLE = "ROLE_USER";

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final RegionRepository regionRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final TokenBlacklistService tokenBlacklistService;

    @Transactional
    public User register(RegisterRequest request) {
        if (userRepository.existsByEmailIgnoreCase(request.email())) {
            throw new DuplicateResourceException("Un compte existe déjà avec cet email");
        }
        if (userRepository.existsByUsernameIgnoreCase(request.username())) {
            throw new DuplicateResourceException("Ce nom d'utilisateur est déjà pris");
        }

        Region region = null;
        if (request.regionId() != null) {
            region = regionRepository.findById(request.regionId())
                    .orElseThrow(() -> new ResourceNotFoundException("Région introuvable, id=" + request.regionId()));
        }

        Set<Role> roles = resolveRoles(request.roles());

        User user = User.builder()
                .email(request.email())
                .username(request.username())
                .password(passwordEncoder.encode(request.password()))
                .region(region)
                .roles(roles)
                .enabled(true)
                .build();

        return userRepository.save(user);
    }

    @Transactional(readOnly = true)
    public AuthResult login(LoginRequest request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.usernameOrEmail(), request.password())
            );
        } catch (BadCredentialsException ex) {
            throw new BadCredentialsException("Identifiants invalides");
        }

        User user = userRepository.findByUsernameIgnoreCaseOrEmailIgnoreCase(request.usernameOrEmail(), request.usernameOrEmail())
                .orElseThrow(() -> new BadCredentialsException("Identifiants invalides"));

        TokenPair tokenPair = generateTokenPair(user);
        return new AuthResult(user, tokenPair);
    }

    /**
     * Rotation du refresh token : l'ancien refresh token est blacklisté dès
     * qu'une nouvelle paire access/refresh est émise (usage unique).
     */
    @Transactional(readOnly = true)
    public AuthResult refresh(String refreshToken) {
        if (refreshToken == null || refreshToken.isBlank()) {
            throw new InvalidTokenException("Refresh token manquant");
        }

        Claims claims;
        try {
            claims = jwtService.parseClaims(refreshToken);
        } catch (JwtException | IllegalArgumentException ex) {
            throw new InvalidTokenException("Refresh token invalide ou expiré");
        }

        if (jwtService.extractType(claims) != TokenType.REFRESH) {
            throw new InvalidTokenException("Type de token invalide pour un rafraîchissement");
        }
        if (tokenBlacklistService.isBlacklisted(claims.getId())) {
            throw new InvalidTokenException("Refresh token révoqué");
        }

        Long userId = jwtService.extractUserId(claims);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new InvalidTokenException("Utilisateur introuvable"));

        if (!user.isEnabled()) {
            throw new InvalidTokenException("Compte désactivé");
        }

        // Rotation : l'ancien refresh token devient immédiatement inutilisable
        tokenBlacklistService.blacklist(claims.getId(), claims.getExpiration().toInstant());

        TokenPair tokenPair = generateTokenPair(user);
        return new AuthResult(user, tokenPair);
    }

    /** Blackliste les tokens courants (access + refresh) pour les invalider immédiatement. */
    public void logout(String accessToken, String refreshToken) {
        blacklistIfValid(accessToken);
        blacklistIfValid(refreshToken);
    }

    private void blacklistIfValid(String token) {
        if (token == null || token.isBlank()) {
            return;
        }
        try {
            Claims claims = jwtService.parseClaims(token);
            tokenBlacklistService.blacklist(claims.getId(), claims.getExpiration().toInstant());
        } catch (JwtException | IllegalArgumentException ignored) {
            // token déjà invalide/expiré : rien à faire
        }
    }

    private TokenPair generateTokenPair(User user) {
        GeneratedToken access = jwtService.generateAccessToken(
                user.getId(), user.getUsername(), UserPrincipal.roleNames(user), UserPrincipal.permissionNames(user));
        GeneratedToken refresh = jwtService.generateRefreshToken(user.getId(), user.getUsername());
        return new TokenPair(access, refresh);
    }

    private Set<Role> resolveRoles(Set<String> requestedRoleNames) {
        if (requestedRoleNames == null || requestedRoleNames.isEmpty()) {
            Role defaultRole = roleRepository.findByNameIgnoreCase(DEFAULT_ROLE)
                    .orElseThrow(() -> new IllegalStateException("Rôle par défaut introuvable : " + DEFAULT_ROLE));
            return new HashSet<>(Set.of(defaultRole));
        }
        return new HashSet<>(roleRepository.findByNameInIgnoreCase(requestedRoleNames));
    }

    public record AuthResult(User user, TokenPair tokenPair) {
    }
}
