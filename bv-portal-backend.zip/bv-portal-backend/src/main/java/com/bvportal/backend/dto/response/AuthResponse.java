package com.bvportal.backend.dto.response;

/**
 * Les tokens ne sont jamais renvoyés dans le corps de la réponse :
 * ils sont posés en cookies HttpOnly côté serveur. On ne renvoie que
 * le profil utilisateur connecté.
 */
public record AuthResponse(
        UserResponse user,
        String message
) {
}
