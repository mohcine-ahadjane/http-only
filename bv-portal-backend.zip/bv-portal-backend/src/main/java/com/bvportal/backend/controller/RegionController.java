package com.bvportal.backend.controller;

import com.bvportal.backend.dto.request.RegionCreateRequest;
import com.bvportal.backend.dto.response.RegionResponse;
import com.bvportal.backend.mapper.GeoMapper;
import com.bvportal.backend.service.GeoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/regions")
@RequiredArgsConstructor
@Tag(name = "Régions", description = "Référentiel géographique - régions")
public class RegionController {

    private final GeoService geoService;

    @GetMapping
    @Operation(summary = "Lister toutes les régions")
    public List<RegionResponse> findAll() {
        return geoService.findAllRegions().stream().map(GeoMapper::toResponse).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('GEO_MANAGE')")
    @Operation(summary = "Créer une région")
    public RegionResponse create(@Valid @RequestBody RegionCreateRequest request) {
        return GeoMapper.toResponse(geoService.createRegion(request));
    }
}
