package com.bvportal.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BvPortalBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(BvPortalBackendApplication.class, args);
    }
}
