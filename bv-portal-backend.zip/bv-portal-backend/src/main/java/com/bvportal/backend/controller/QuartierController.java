package com.bvportal.backend.controller;

import com.bvportal.backend.dto.request.QuartierCreateRequest;
import com.bvportal.backend.dto.response.QuartierResponse;
import com.bvportal.backend.mapper.GeoMapper;
import com.bvportal.backend.service.GeoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/quartiers")
@RequiredArgsConstructor
@Tag(name = "Quartiers", description = "Référentiel géographique - quartiers")
public class QuartierController {

    private final GeoService geoService;

    @GetMapping
    @Operation(summary = "Lister les quartiers d'une ville (villeId obligatoire)")
    public List<QuartierResponse> findByVille(@RequestParam Long villeId) {
        return geoService.findQuartiersByVille(villeId).stream().map(GeoMapper::toResponse).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('GEO_MANAGE')")
    @Operation(summary = "Créer un quartier")
    public QuartierResponse create(@Valid @RequestBody QuartierCreateRequest request) {
        return GeoMapper.toResponse(geoService.createQuartier(request));
    }
}
