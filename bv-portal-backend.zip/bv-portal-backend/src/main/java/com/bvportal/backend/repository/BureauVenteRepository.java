package com.bvportal.backend.repository;

import com.bvportal.backend.domain.entity.BureauVente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BureauVenteRepository extends JpaRepository<BureauVente, Long> {

    List<BureauVente> findByQuartier_IdOrderByNameAsc(Long quartierId);

    List<BureauVente> findByQuartier_Ville_IdOrderByNameAsc(Long villeId);

    /** Tous les BV appartenant à une région donnée (sélection directe sans filtre). */
    List<BureauVente> findByQuartier_Ville_Region_IdOrderByNameAsc(Long regionId);

    boolean existsByNameIgnoreCaseAndQuartier_Id(String name, Long quartierId);

    boolean existsByIdAndQuartier_Ville_Region_Id(Long id, Long regionId);
}
