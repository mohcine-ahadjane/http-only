package com.bvportal.backend.mapper;

import com.bvportal.backend.domain.entity.BureauVente;
import com.bvportal.backend.domain.entity.Quartier;
import com.bvportal.backend.domain.entity.Region;
import com.bvportal.backend.domain.entity.Ville;
import com.bvportal.backend.dto.response.BureauVenteResponse;
import com.bvportal.backend.dto.response.QuartierResponse;
import com.bvportal.backend.dto.response.RegionResponse;
import com.bvportal.backend.dto.response.VilleResponse;

public final class GeoMapper {

    private GeoMapper() {
    }

    public static RegionResponse toResponse(Region region) {
        return new RegionResponse(region.getId(), region.getName());
    }

    public static VilleResponse toResponse(Ville ville) {
        return new VilleResponse(
                ville.getId(),
                ville.getName(),
                ville.getRegion().getId(),
                ville.getRegion().getName()
        );
    }

    public static QuartierResponse toResponse(Quartier quartier) {
        return new QuartierResponse(
                quartier.getId(),
                quartier.getName(),
                quartier.getVille().getId(),
                quartier.getVille().getName()
        );
    }

    public static BureauVenteResponse toResponse(BureauVente bv) {
        Quartier quartier = bv.getQuartier();
        Ville ville = quartier.getVille();
        Region region = ville.getRegion();
        return new BureauVenteResponse(
                bv.getId(),
                bv.getName(),
                bv.getCode(),
                bv.isActive(),
                quartier.getId(),
                quartier.getName(),
                ville.getId(),
                ville.getName(),
                region.getId(),
                region.getName()
        );
    }
}
