package com.bvportal.backend.repository;

import com.bvportal.backend.domain.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByNameIgnoreCase(String name);
    List<Role> findByNameInIgnoreCase(Collection<String> names);
}
