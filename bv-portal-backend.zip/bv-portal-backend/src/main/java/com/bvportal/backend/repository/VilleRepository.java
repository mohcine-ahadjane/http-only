package com.bvportal.backend.repository;

import com.bvportal.backend.domain.entity.Ville;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VilleRepository extends JpaRepository<Ville, Long> {

    List<Ville> findByRegion_IdOrderByNameAsc(Long regionId);

    boolean existsByNameIgnoreCaseAndRegion_Id(String name, Long regionId);

    boolean existsByIdAndRegion_Id(Long id, Long regionId);
}
