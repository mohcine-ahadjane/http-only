package com.bvportal.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record QuartierCreateRequest(
        @NotBlank(message = "Le nom du quartier est obligatoire")
        @Size(max = 100)
        String name,

        @NotNull(message = "La ville est obligatoire")
        Long villeId
) {
}
