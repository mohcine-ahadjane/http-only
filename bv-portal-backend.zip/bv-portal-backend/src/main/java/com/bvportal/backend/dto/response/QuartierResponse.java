package com.bvportal.backend.dto.response;

public record QuartierResponse(
        Long id,
        String name,
        Long villeId,
        String villeName
) {
}
