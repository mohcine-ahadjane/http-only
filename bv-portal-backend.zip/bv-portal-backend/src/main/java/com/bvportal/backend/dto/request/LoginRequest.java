package com.bvportal.backend.dto.request;

import jakarta.validation.constraints.NotBlank;

public record LoginRequest(

        @NotBlank(message = "Le nom d'utilisateur ou l'email est obligatoire")
        String usernameOrEmail,

        @NotBlank(message = "Le mot de passe est obligatoire")
        String password
) {
}
