package com.bvportal.backend.controller;

import com.bvportal.backend.dto.response.BureauVenteResponse;
import com.bvportal.backend.dto.response.QuartierResponse;
import com.bvportal.backend.dto.response.UserResponse;
import com.bvportal.backend.dto.response.VilleResponse;
import com.bvportal.backend.mapper.GeoMapper;
import com.bvportal.backend.mapper.UserMapper;
import com.bvportal.backend.security.CurrentUserProvider;
import com.bvportal.backend.service.MeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Endpoints dédiés à l'utilisateur connecté au portail :
 * - son profil
 * - les listes à utiliser dans les sélecteurs front (villes -> quartiers -> bureaux de vente)
 *   toutes scopées à sa région, avec sélection directe du BV possible (sans filtre).
 */
@RestController
@RequestMapping("/api/v1/me")
@RequiredArgsConstructor
@Tag(name = "Espace utilisateur (Me)", description = "Profil et navigation géographique de l'utilisateur connecté")
public class MeController {

    private final MeService meService;
    private final CurrentUserProvider currentUserProvider;

    @GetMapping
    @Operation(summary = "Profil de l'utilisateur connecté")
    public UserResponse getProfile() {
        Long userId = currentUserProvider.getCurrentUserId();
        return UserMapper.toResponse(meService.getCurrentUserEntity(userId));
    }

    @GetMapping("/villes")
    @Operation(summary = "Villes de la région gérée par l'utilisateur connecté")
    public List<VilleResponse> getMyVilles() {
        Long userId = currentUserProvider.getCurrentUserId();
        return meService.getMyVilles(userId).stream().map(GeoMapper::toResponse).toList();
    }

    @GetMapping("/quartiers")
    @Operation(summary = "Quartiers de la région de l'utilisateur, filtrables par ville (villeId)")
    public List<QuartierResponse> getMyQuartiers(@RequestParam(required = false) Long villeId) {
        Long userId = currentUserProvider.getCurrentUserId();
        return meService.getMyQuartiers(userId, villeId).stream().map(GeoMapper::toResponse).toList();
    }

    @GetMapping("/bureaux-vente")
    @Operation(summary = "Bureaux de vente de l'utilisateur : sélection directe (aucun filtre), "
            + "ou filtrage par villeId et/ou quartierId")
    public List<BureauVenteResponse> getMyBureauxVente(@RequestParam(required = false) Long villeId,
                                                         @RequestParam(required = false) Long quartierId) {
        Long userId = currentUserProvider.getCurrentUserId();
        return meService.getMyBureauxVente(userId, villeId, quartierId).stream().map(GeoMapper::toResponse).toList();
    }
}
