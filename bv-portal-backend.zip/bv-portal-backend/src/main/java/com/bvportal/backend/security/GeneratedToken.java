package com.bvportal.backend.security;

import java.time.Instant;

public record GeneratedToken(String token, String jti, Instant expiresAt) {
}
