package com.bvportal.backend.security;

public record AuthenticatedUser(Long id, String username) {
}
