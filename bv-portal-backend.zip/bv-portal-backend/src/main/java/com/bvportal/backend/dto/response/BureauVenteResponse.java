package com.bvportal.backend.dto.response;

public record BureauVenteResponse(
        Long id,
        String name,
        String code,
        boolean active,
        Long quartierId,
        String quartierName,
        Long villeId,
        String villeName,
        Long regionId,
        String regionName
) {
}
