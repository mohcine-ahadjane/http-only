package com.bvportal.backend.repository;

import com.bvportal.backend.domain.entity.Quartier;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuartierRepository extends JpaRepository<Quartier, Long> {

    List<Quartier> findByVille_IdOrderByNameAsc(Long villeId);

    List<Quartier> findByVille_Region_IdOrderByNameAsc(Long regionId);

    boolean existsByNameIgnoreCaseAndVille_Id(String name, Long villeId);

    boolean existsByIdAndVille_Region_Id(Long id, Long regionId);

    boolean existsByIdAndVille_Id(Long id, Long villeId);
}
