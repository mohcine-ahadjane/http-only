package com.bvportal.backend.controller;

import com.bvportal.backend.dto.request.VilleCreateRequest;
import com.bvportal.backend.dto.response.VilleResponse;
import com.bvportal.backend.mapper.GeoMapper;
import com.bvportal.backend.service.GeoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/villes")
@RequiredArgsConstructor
@Tag(name = "Villes", description = "Référentiel géographique - villes")
public class VilleController {

    private final GeoService geoService;

    @GetMapping
    @Operation(summary = "Lister les villes d'une région (regionId obligatoire)")
    public List<VilleResponse> findByRegion(@RequestParam Long regionId) {
        return geoService.findVillesByRegion(regionId).stream().map(GeoMapper::toResponse).toList();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('GEO_MANAGE')")
    @Operation(summary = "Créer une ville")
    public VilleResponse create(@Valid @RequestBody VilleCreateRequest request) {
        return GeoMapper.toResponse(geoService.createVille(request));
    }
}
