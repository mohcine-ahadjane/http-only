package com.bvportal.backend.security;

import com.bvportal.backend.domain.entity.User;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Getter
public class UserPrincipal implements UserDetails {

    private final Long id;
    private final String username;
    private final String email;
    private final String password;
    private final boolean enabled;
    private final Long regionId;
    private final Collection<? extends GrantedAuthority> authorities;

    public UserPrincipal(User user) {
        this.id = user.getId();
        this.username = user.getUsername();
        this.email = user.getEmail();
        this.password = user.getPassword();
        this.enabled = user.isEnabled();
        this.regionId = user.getRegion() != null ? user.getRegion().getId() : null;

        // Autorités : ROLE_X pour chaque rôle + le nom brut de chaque permission (ex: BV_READ)
        Stream<String> roleAuthorities = user.getRoles().stream().map(r -> "ROLE_" + stripRolePrefix(r.getName()));
        Stream<String> permissionAuthorities = user.getRoles().stream()
                .flatMap(r -> r.getPermissions().stream())
                .map(p -> p.getName())
                .distinct();

        this.authorities = Stream.concat(roleAuthorities, permissionAuthorities)
                .distinct()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toUnmodifiableList());
    }

    private static String stripRolePrefix(String name) {
        return name.startsWith("ROLE_") ? name.substring(5) : name;
    }

    public static List<String> roleNames(User user) {
        return user.getRoles().stream().map(r -> r.getName()).distinct().toList();
    }

    public static List<String> permissionNames(User user) {
        return user.getRoles().stream()
                .flatMap(r -> r.getPermissions().stream())
                .map(p -> p.getName())
                .distinct()
                .toList();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }
}
