package com.bvportal.backend.exception;

/** Token absent, malformé, expiré, blacklisté ou de type incorrect. */
public class InvalidTokenException extends RuntimeException {
    public InvalidTokenException(String message) {
        super(message);
    }
}
