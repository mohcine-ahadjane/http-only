package com.bvportal.backend.exception;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ApiError(
        Instant timestamp,
        int status,
        String error,
        String message,
        String path,
        List<FieldErrorDetail> fieldErrors
) {
    public record FieldErrorDetail(String field, String message) {
    }

    public static ApiError of(int status, String error, String message, String path) {
        return new ApiError(Instant.now(), status, error, message, path, null);
    }

    public static ApiError ofValidation(int status, String error, String message, String path, List<FieldErrorDetail> fieldErrors) {
        return new ApiError(Instant.now(), status, error, message, path, fieldErrors);
    }

    public static ApiError of(int status, String error, String message, String path, Map<String, String> errors) {
        List<FieldErrorDetail> details = errors.entrySet().stream()
                .map(e -> new FieldErrorDetail(e.getKey(), e.getValue()))
                .toList();
        return ofValidation(status, error, message, path, details);
    }
}
