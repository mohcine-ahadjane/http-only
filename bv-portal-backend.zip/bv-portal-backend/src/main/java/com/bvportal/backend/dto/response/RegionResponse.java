package com.bvportal.backend.dto.response;

public record RegionResponse(
        Long id,
        String name
) {
}
