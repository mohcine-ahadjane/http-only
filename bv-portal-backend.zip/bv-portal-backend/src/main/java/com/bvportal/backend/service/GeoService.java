package com.bvportal.backend.service;

import com.bvportal.backend.domain.entity.BureauVente;
import com.bvportal.backend.domain.entity.Quartier;
import com.bvportal.backend.domain.entity.Region;
import com.bvportal.backend.domain.entity.Ville;
import com.bvportal.backend.dto.request.BureauVenteCreateRequest;
import com.bvportal.backend.dto.request.QuartierCreateRequest;
import com.bvportal.backend.dto.request.RegionCreateRequest;
import com.bvportal.backend.dto.request.VilleCreateRequest;
import com.bvportal.backend.exception.DuplicateResourceException;
import com.bvportal.backend.exception.ResourceNotFoundException;
import com.bvportal.backend.repository.BureauVenteRepository;
import com.bvportal.backend.repository.QuartierRepository;
import com.bvportal.backend.repository.RegionRepository;
import com.bvportal.backend.repository.VilleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class GeoService {

    private final RegionRepository regionRepository;
    private final VilleRepository villeRepository;
    private final QuartierRepository quartierRepository;
    private final BureauVenteRepository bureauVenteRepository;

    // ---------- Lecture ----------

    public List<Region> findAllRegions() {
        return regionRepository.findAll();
    }

    public List<Ville> findVillesByRegion(Long regionId) {
        ensureRegionExists(regionId);
        return villeRepository.findByRegion_IdOrderByNameAsc(regionId);
    }

    public List<Quartier> findQuartiersByVille(Long villeId) {
        ensureVilleExists(villeId);
        return quartierRepository.findByVille_IdOrderByNameAsc(villeId);
    }

    public List<BureauVente> findBureauxByQuartier(Long quartierId) {
        ensureQuartierExists(quartierId);
        return bureauVenteRepository.findByQuartier_IdOrderByNameAsc(quartierId);
    }

    public List<BureauVente> findBureauxByVille(Long villeId) {
        ensureVilleExists(villeId);
        return bureauVenteRepository.findByQuartier_Ville_IdOrderByNameAsc(villeId);
    }

    public List<BureauVente> findBureauxByRegion(Long regionId) {
        ensureRegionExists(regionId);
        return bureauVenteRepository.findByQuartier_Ville_Region_IdOrderByNameAsc(regionId);
    }

    public List<Quartier> findQuartiersByRegion(Long regionId) {
        ensureRegionExists(regionId);
        return quartierRepository.findByVille_Region_IdOrderByNameAsc(regionId);
    }

    // ---------- Écriture (administration des référentiels géographiques) ----------

    @Transactional
    public Region createRegion(RegionCreateRequest request) {
        if (regionRepository.existsByNameIgnoreCase(request.name())) {
            throw new DuplicateResourceException("Une région avec ce nom existe déjà : " + request.name());
        }
        return regionRepository.save(Region.builder().name(request.name()).build());
    }

    @Transactional
    public Ville createVille(VilleCreateRequest request) {
        Region region = regionRepository.findById(request.regionId())
                .orElseThrow(() -> new ResourceNotFoundException("Région introuvable, id=" + request.regionId()));

        if (villeRepository.existsByNameIgnoreCaseAndRegion_Id(request.name(), region.getId())) {
            throw new DuplicateResourceException("Une ville avec ce nom existe déjà dans cette région : " + request.name());
        }

        return villeRepository.save(Ville.builder().name(request.name()).region(region).build());
    }

    @Transactional
    public Quartier createQuartier(QuartierCreateRequest request) {
        Ville ville = villeRepository.findById(request.villeId())
                .orElseThrow(() -> new ResourceNotFoundException("Ville introuvable, id=" + request.villeId()));

        if (quartierRepository.existsByNameIgnoreCaseAndVille_Id(request.name(), ville.getId())) {
            throw new DuplicateResourceException("Un quartier avec ce nom existe déjà dans cette ville : " + request.name());
        }

        return quartierRepository.save(Quartier.builder().name(request.name()).ville(ville).build());
    }

    @Transactional
    public BureauVente createBureauVente(BureauVenteCreateRequest request) {
        Quartier quartier = quartierRepository.findById(request.quartierId())
                .orElseThrow(() -> new ResourceNotFoundException("Quartier introuvable, id=" + request.quartierId()));

        if (bureauVenteRepository.existsByNameIgnoreCaseAndQuartier_Id(request.name(), quartier.getId())) {
            throw new DuplicateResourceException("Un bureau de vente avec ce nom existe déjà dans ce quartier : " + request.name());
        }

        BureauVente bv = BureauVente.builder()
                .name(request.name())
                .code(request.code())
                .quartier(quartier)
                .active(true)
                .build();

        return bureauVenteRepository.save(bv);
    }

    // ---------- Vérifications d'appartenance (utilisées par MeService pour éviter les fuites inter-région) ----------

    public boolean villeBelongsToRegion(Long villeId, Long regionId) {
        return villeRepository.existsByIdAndRegion_Id(villeId, regionId);
    }

    public boolean quartierBelongsToRegion(Long quartierId, Long regionId) {
        return quartierRepository.existsByIdAndVille_Region_Id(quartierId, regionId);
    }

    public boolean quartierBelongsToVille(Long quartierId, Long villeId) {
        return quartierRepository.existsByIdAndVille_Id(quartierId, villeId);
    }

    private void ensureRegionExists(Long regionId) {
        if (!regionRepository.existsById(regionId)) {
            throw new ResourceNotFoundException("Région introuvable, id=" + regionId);
        }
    }

    private void ensureVilleExists(Long villeId) {
        if (!villeRepository.existsById(villeId)) {
            throw new ResourceNotFoundException("Ville introuvable, id=" + villeId);
        }
    }

    private void ensureQuartierExists(Long quartierId) {
        if (!quartierRepository.existsById(quartierId)) {
            throw new ResourceNotFoundException("Quartier introuvable, id=" + quartierId);
        }
    }
}
