package com.bvportal.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record BureauVenteCreateRequest(
        @NotBlank(message = "Le nom du bureau de vente est obligatoire")
        @Size(max = 150)
        String name,

        @Size(max = 50)
        String code,

        @NotNull(message = "Le quartier est obligatoire")
        Long quartierId
) {
}
