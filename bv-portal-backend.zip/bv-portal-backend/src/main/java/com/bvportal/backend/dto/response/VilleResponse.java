package com.bvportal.backend.dto.response;

public record VilleResponse(
        Long id,
        String name,
        Long regionId,
        String regionName
) {
}
