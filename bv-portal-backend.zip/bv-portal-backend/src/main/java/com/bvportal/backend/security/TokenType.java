package com.bvportal.backend.security;

public enum TokenType {
    ACCESS,
    REFRESH
}
