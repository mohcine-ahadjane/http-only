package com.bvportal.backend.exception;

/** L'utilisateur authentifié n'a pas le droit d'accéder à la ressource demandée (hors RBAC). */
public class ForbiddenOperationException extends RuntimeException {
    public ForbiddenOperationException(String message) {
        super(message);
    }
}
