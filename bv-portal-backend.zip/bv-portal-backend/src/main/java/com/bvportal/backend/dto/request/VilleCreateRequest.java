package com.bvportal.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record VilleCreateRequest(
        @NotBlank(message = "Le nom de la ville est obligatoire")
        @Size(max = 100)
        String name,

        @NotNull(message = "La région est obligatoire")
        Long regionId
) {
}
