package com.bvportal.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record RegionCreateRequest(
        @NotBlank(message = "Le nom de la région est obligatoire")
        @Size(max = 100)
        String name
) {
}
