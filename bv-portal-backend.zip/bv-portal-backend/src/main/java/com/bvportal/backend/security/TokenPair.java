package com.bvportal.backend.security;

public record TokenPair(GeneratedToken accessToken, GeneratedToken refreshToken) {
}
