package com.bvportal.backend.controller;

import com.bvportal.backend.dto.request.LoginRequest;
import com.bvportal.backend.dto.request.RegisterRequest;
import com.bvportal.backend.dto.response.AuthResponse;
import com.bvportal.backend.dto.response.UserResponse;
import com.bvportal.backend.mapper.UserMapper;
import com.bvportal.backend.security.CookieUtil;
import com.bvportal.backend.security.GeneratedToken;
import com.bvportal.backend.security.TokenPair;
import com.bvportal.backend.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.Instant;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Tag(name = "Authentification", description = "Inscription, connexion, rotation des tokens et déconnexion")
public class AuthController {

    private final AuthService authService;
    private final CookieUtil cookieUtil;

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Créer un compte utilisateur")
    public UserResponse register(@Valid @RequestBody RegisterRequest request) {
        var user = authService.register(request);
        return UserMapper.toResponse(user);
    }

    @PostMapping("/login")
    @Operation(summary = "Se connecter (pose les cookies HttpOnly access_token / refresh_token)")
    public AuthResponse login(@Valid @RequestBody LoginRequest request, HttpServletResponse response) {
        var result = authService.login(request);
        setAuthCookies(response, result.tokenPair());
        return new AuthResponse(UserMapper.toResponse(result.user()), "Connexion réussie");
    }

    @PostMapping("/refresh")
    @Operation(summary = "Rafraîchir les tokens (rotation du refresh token)")
    public AuthResponse refresh(@CookieValue(value = CookieUtil.REFRESH_TOKEN_COOKIE, required = false) String refreshToken,
                                 HttpServletResponse response) {
        var result = authService.refresh(refreshToken);
        setAuthCookies(response, result.tokenPair());
        return new AuthResponse(UserMapper.toResponse(result.user()), "Tokens rafraîchis");
    }

    @PostMapping("/logout")
    @Operation(summary = "Se déconnecter (blackliste et efface les cookies)")
    public ResponseEntity<Void> logout(
            @CookieValue(value = CookieUtil.ACCESS_TOKEN_COOKIE, required = false) String accessToken,
            @CookieValue(value = CookieUtil.REFRESH_TOKEN_COOKIE, required = false) String refreshToken,
            HttpServletResponse response) {

        authService.logout(accessToken, refreshToken);
        cookieUtil.clearCookie(response, CookieUtil.ACCESS_TOKEN_COOKIE);
        cookieUtil.clearCookie(response, CookieUtil.REFRESH_TOKEN_COOKIE);
        return ResponseEntity.noContent().build();
    }

    private void setAuthCookies(HttpServletResponse response, TokenPair tokenPair) {
        GeneratedToken access = tokenPair.accessToken();
        GeneratedToken refresh = tokenPair.refreshToken();

        cookieUtil.addCookie(response, CookieUtil.ACCESS_TOKEN_COOKIE, access.token(), durationUntil(access.expiresAt()));
        cookieUtil.addCookie(response, CookieUtil.REFRESH_TOKEN_COOKIE, refresh.token(), durationUntil(refresh.expiresAt()));
    }

    private Duration durationUntil(Instant instant) {
        return Duration.between(Instant.now(), instant);
    }
}
