# Portail Responsable — Backend (Spring Boot 3.5 / Java 21)

API REST stateless avec authentification **JWT en cookies HttpOnly**, **rotation des refresh tokens**,
**blacklist Redis**, et **RBAC** (utilisateurs / rôles / permissions), exposant les endpoints du
portail responsable pour la sélection en cascade Région → Ville → Quartier → Bureau de vente.

## Stack
- Java 21, Spring Boot 3.5
- Spring Security (filtre JWT stateless, pas de session)
- Spring Data JPA + PostgreSQL
- Flyway (migrations versionnées, `ddl-auto: validate`)
- Redis (blacklist des tokens révoqués + whitelist du refresh token courant)
- springdoc-openapi (Swagger UI)
- Bean Validation (Jakarta) sur tous les DTO d'entrée
- Lombok

## Démarrage rapide

```bash
docker compose up -d        # Postgres + Redis
mvn spring-boot:run
```

- Swagger UI : http://localhost:8080/swagger-ui.html
- Un utilisateur **responsable** de démonstration est créé par la migration `V2__sample_data.sql`
  (username `responsable.demo`, region "Region Rabat-Sale-Kenitra"). **Régénérez son hash BCrypt**
  avant tout usage réel — le hash fourni est un exemple, pas un mot de passe garanti.

## Modèle métier (diagramme de classes résumé)

```
Region (1) ──< (N) Responsable        [même rôle RESPONSABLE]
Region (1) ──< (N) Ville
Ville  (1) ──< (N) Quartier
Quartier (1) ──< (N) BureauVente
Responsable (1) ── (1) User
```

Un responsable gère uniquement les bureaux de vente (BV) de **sa** région, via les villes et
quartiers qui la composent. Chaque accès aux ressources imbriquées est revérifié côté serveur
(le quartier/ville/BV ciblé doit appartenir à la région du responsable connecté) — pas seulement
filtré en façade.

## RBAC

- `users` — `roles` (N:N) — `permissions` (N:N sur `roles`)
- Rôles seedés : `ADMIN`, `RESPONSABLE`, `USER`
- À l'inscription, seul le rôle `USER` est attribué automatiquement (le rôle ne vient jamais du
  client). L'attribution du rôle `RESPONSABLE` + la création de l'enregistrement `responsables`
  est une opération d'administration, hors périmètre de `/register` par conception (sécurité).

## Authentification — `/api/auth`

| Méthode | Endpoint   | Description |
|---------|-----------|--------------|
| POST | `/register` | Crée un compte (`email`, `username`, `password`, `siege`) — rôle `USER` par défaut |
| POST | `/login`    | Vérifie les identifiants, pose les cookies `access_token` et `refresh_token` |
| POST | `/refresh`  | Rotation: invalide l'ancien refresh token (jti) et en émet un nouveau couple |
| POST | `/logout`   | Blacklist les tokens courants (access + refresh) et efface les cookies |

### Cookies HttpOnly
- `access_token` — `HttpOnly`, `Secure` (configurable), `SameSite=Strict`, path `/api`, TTL 15 min
- `refresh_token` — mêmes attributs, path restreint à `/api/auth`, TTL 7 jours
- Aucun token n'est jamais renvoyé dans le corps JSON des réponses.

### Rotation & révocation (Redis)
- Chaque refresh token porte un `jti` unique. Le `jti` "courant" par utilisateur est stocké dans
  Redis (`refresh:user:{id}`). Au `refresh`, le `jti` présenté doit correspondre à celui stocké :
  - ✅ correspondance → ancien token blacklisté (`blacklist:jti:{jti}`, TTL = expiration restante),
    nouveau couple access/refresh émis et stocké.
  - ❌ pas de correspondance (réutilisation d'un ancien token / vol) → toute la session de
    l'utilisateur est révoquée immédiatement.
- Le `logout` blackliste explicitement le `jti` de l'access token et du refresh token en cours.
- Le filtre `JwtAuthFilter` rejette toute requête dont le `jti` de l'access token est blacklisté.

## Portail Responsable — `/api/responsable` (authentifié)

| Méthode | Endpoint | Usage front |
|---------|----------|-------------|
| GET | `/region` | Affiche la région gérée par le responsable connecté |
| GET | `/villes` | Liste des villes de sa région (étape 1 du filtre) |
| GET | `/villes/{villeId}/quartiers` | Liste des quartiers de la ville sélectionnée (étape 2) |
| GET | `/quartiers/{quartierId}/bureaux` | Liste des BV du quartier sélectionné (étape 3) |
| GET | `/bureaux` | **Sélection directe** : tous les BV de sa région, sans passer par le filtre |
| GET | `/bureaux/{bvId}` | Détail d'un BV (vérifie qu'il appartient à sa région) |

Le responsable courant est résolu depuis le `userId` porté par le JWT (principal
`AuthenticatedUser`), jamais depuis un paramètre client.

## Gestion des erreurs

`GlobalExceptionHandler` (`@RestControllerAdvice`) normalise toutes les réponses d'erreur au format :

```json
{
  "timestamp": "...",
  "status": 404,
  "error": "Not Found",
  "message": "...",
  "path": "/api/...",
  "details": null
}
```

401 (non authentifié) et 403 (accès refusé) sont aussi renvoyés au même format via
`RestAuthEntryPoint` / `RestAccessDeniedHandler`.

## Notes "minimum légal / version light"

- Pas de gestion de mot de passe oublié, MFA, vérification d'email : volontairement hors périmètre.
- Pas d'endpoints d'administration RBAC (création de rôles/permissions/responsables) : à seeder via
  Flyway ou à ajouter dans un module `admin` séparé si besoin.
- CORS configuré avec `allowCredentials(true)` (indispensable pour les cookies cross-origin) —
  adapter `allowedOrigins` à l'URL réelle du front avant mise en production.
- `app.jwt.secret` et les identifiants Postgres/Redis dans `application.yml` sont des valeurs de
  développement : à externaliser (variables d'environnement / secrets manager) en production.
