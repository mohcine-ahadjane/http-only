package com.example.app.service;

import com.example.app.dto.region.BureauVenteResponse;
import com.example.app.dto.region.QuartierResponse;
import com.example.app.dto.region.RegionResponse;
import com.example.app.dto.region.VilleResponse;
import com.example.app.entity.Responsable;
import com.example.app.exception.ResourceNotFoundException;
import com.example.app.mapper.RegionMapper;
import com.example.app.repository.BureauVenteRepository;
import com.example.app.repository.QuartierRepository;
import com.example.app.repository.ResponsableRepository;
import com.example.app.repository.VilleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Logique du portail du responsable connecte:
 * - selection directe d'un BV de sa region
 * - ou filtrage en cascade: ville -> quartier -> BV
 * Toute selection est verifiee comme appartenant a la region du responsable
 * (defense en profondeur, en plus du filtrage des requetes).
 */
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ResponsablePortalService {

    private final ResponsableRepository responsableRepository;
    private final VilleRepository villeRepository;
    private final QuartierRepository quartierRepository;
    private final BureauVenteRepository bureauVenteRepository;

    public Responsable getResponsableOrThrow(Long userId) {
        return responsableRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Aucun profil responsable associe a cet utilisateur"));
    }

    public RegionResponse getMyRegion(Long userId) {
        Responsable responsable = getResponsableOrThrow(userId);
        return RegionMapper.toResponse(responsable.getRegion());
    }

    public List<VilleResponse> getMyVilles(Long userId) {
        Responsable responsable = getResponsableOrThrow(userId);
        return villeRepository.findByRegionIdOrderByNameAsc(responsable.getRegion().getId())
                .stream().map(RegionMapper::toResponse).toList();
    }

    public List<QuartierResponse> getQuartiersOfVille(Long userId, Long villeId) {
        Responsable responsable = getResponsableOrThrow(userId);
        if (!villeRepository.existsByIdAndRegionId(villeId, responsable.getRegion().getId())) {
            throw new AccessDeniedException("Cette ville n'appartient pas a votre region");
        }
        return quartierRepository.findByVilleIdOrderByNameAsc(villeId)
                .stream().map(RegionMapper::toResponse).toList();
    }

    public List<BureauVenteResponse> getBureauxOfQuartier(Long userId, Long quartierId) {
        Responsable responsable = getResponsableOrThrow(userId);
        if (!quartierRepository.existsByIdAndVilleRegionId(quartierId, responsable.getRegion().getId())) {
            throw new AccessDeniedException("Ce quartier n'appartient pas a votre region");
        }
        return bureauVenteRepository.findByQuartierIdOrderByNameAsc(quartierId)
                .stream().map(RegionMapper::toResponse).toList();
    }

    /** Selection directe de tous les BV de la region du responsable (sans passer par ville/quartier). */
    public List<BureauVenteResponse> getAllMyBureaux(Long userId) {
        Responsable responsable = getResponsableOrThrow(userId);
        return bureauVenteRepository.findByQuartier_Ville_Region_IdOrderByNameAsc(responsable.getRegion().getId())
                .stream().map(RegionMapper::toResponse).toList();
    }

    public BureauVenteResponse getMyBureauById(Long userId, Long bvId) {
        Responsable responsable = getResponsableOrThrow(userId);
        if (!bureauVenteRepository.existsByIdAndQuartier_Ville_Region_Id(bvId, responsable.getRegion().getId())) {
            throw new AccessDeniedException("Ce bureau de vente n'appartient pas a votre region");
        }
        return bureauVenteRepository.findById(bvId)
                .map(com.example.app.mapper.RegionMapper::toResponse)
                .orElseThrow(() -> new ResourceNotFoundException("Bureau de vente introuvable"));
    }
}
