package com.example.app.service;

import com.example.app.dto.auth.LoginRequest;
import com.example.app.dto.auth.RegisterRequest;
import com.example.app.entity.Role;
import com.example.app.entity.User;
import com.example.app.exception.DuplicateResourceException;
import com.example.app.exception.InvalidCredentialsException;
import com.example.app.exception.InvalidTokenException;
import com.example.app.exception.ResourceNotFoundException;
import com.example.app.repository.RoleRepository;
import com.example.app.repository.UserRepository;
import com.example.app.security.JwtService;
import com.example.app.security.RefreshTokenStore;
import com.example.app.security.TokenBlacklistService;
import io.jsonwebtoken.JwtException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AuthService {

    private static final String DEFAULT_ROLE = "USER";

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final TokenBlacklistService tokenBlacklistService;
    private final RefreshTokenStore refreshTokenStore;

    public record TokenPair(String accessToken, String refreshToken, long accessTtl, long refreshTtl) {}

    @Transactional
    public User register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.email())) {
            throw new DuplicateResourceException("Un compte existe deja avec cet email");
        }
        if (userRepository.existsByUsername(request.username())) {
            throw new DuplicateResourceException("Ce username est deja utilise");
        }

        Role defaultRole = roleRepository.findByName(DEFAULT_ROLE)
                .orElseThrow(() -> new ResourceNotFoundException("Role par defaut introuvable: " + DEFAULT_ROLE));

        User user = User.builder()
                .email(request.email())
                .username(request.username())
                .password(passwordEncoder.encode(request.password()))
                .siege(request.siege())
                .enabled(true)
                .roles(new java.util.HashSet<>(List.of(defaultRole)))
                .build();

        return userRepository.save(user);
    }

    @Transactional(readOnly = true)
    public User authenticate(LoginRequest request) {
        User user = userRepository.findByEmail(request.identifier())
                .or(() -> userRepository.findByUsername(request.identifier()))
                .orElseThrow(() -> new InvalidCredentialsException("Identifiants invalides"));

        if (!user.isEnabled()) {
            throw new InvalidCredentialsException("Compte desactive");
        }
        if (!passwordEncoder.matches(request.password(), user.getPassword())) {
            throw new InvalidCredentialsException("Identifiants invalides");
        }
        return user;
    }

    public TokenPair issueTokens(User user) {
        List<String> roles = user.getRoles().stream().map(Role::getName).toList();
        List<String> permissions = user.getRoles().stream()
                .flatMap(r -> r.getPermissions().stream())
                .map(p -> p.getName())
                .distinct()
                .collect(Collectors.toList());

        String accessToken = jwtService.generateAccessToken(user.getId(), user.getUsername(), roles, permissions);

        String refreshJti = UUID.randomUUID().toString();
        String refreshToken = jwtService.generateRefreshToken(user.getId(), refreshJti);
        refreshTokenStore.store(user.getId(), refreshJti, jwtService.refreshTokenTtlSeconds());

        return new TokenPair(accessToken, refreshToken, jwtService.accessTokenTtlSeconds(), jwtService.refreshTokenTtlSeconds());
    }

    /**
     * Rotation stricte: le refresh token presente doit correspondre au jti
     * actuellement enregistre pour cet utilisateur. Sinon -> revocation totale
     * (suspicion de vol/reutilisation de token).
     */
    @Transactional(readOnly = true)
    public TokenPair refresh(String refreshToken) {
        if (refreshToken == null) {
            throw new InvalidTokenException("Refresh token manquant");
        }

        Long userId;
        String jti;
        try {
            if (!"REFRESH".equals(jwtService.getTokenType(refreshToken))) {
                throw new InvalidTokenException("Type de token invalide");
            }
            if (jwtService.isExpired(refreshToken)) {
                throw new InvalidTokenException("Refresh token expire");
            }
            userId = jwtService.getUserId(refreshToken);
            jti = jwtService.getJti(refreshToken);
        } catch (JwtException | IllegalArgumentException e) {
            throw new InvalidTokenException("Refresh token invalide");
        }

        if (tokenBlacklistService.isBlacklisted(jti)) {
            throw new InvalidTokenException("Refresh token revoque");
        }

        if (!refreshTokenStore.isCurrent(userId, jti)) {
            // Reutilisation detectee : on revoque toute la session de l'utilisateur
            refreshTokenStore.revoke(userId);
            throw new InvalidTokenException("Refresh token invalide ou deja utilise");
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new InvalidTokenException("Utilisateur introuvable"));

        // Rotation: l'ancien refresh token est blackliste, un nouveau couple est emis
        tokenBlacklistService.blacklist(jti, jwtService.remainingTtlSeconds(refreshToken));

        return issueTokens(user);
    }

    public void logout(String accessToken, String refreshToken) {
        if (accessToken != null) {
            try {
                String jti = jwtService.getJti(accessToken);
                tokenBlacklistService.blacklist(jti, jwtService.remainingTtlSeconds(accessToken));
            } catch (JwtException | IllegalArgumentException ignored) {
                // token deja invalide: rien a faire
            }
        }
        if (refreshToken != null) {
            try {
                Long userId = jwtService.getUserId(refreshToken);
                String jti = jwtService.getJti(refreshToken);
                tokenBlacklistService.blacklist(jti, jwtService.remainingTtlSeconds(refreshToken));
                refreshTokenStore.revoke(userId);
            } catch (JwtException | IllegalArgumentException ignored) {
                // token deja invalide: rien a faire
            }
        }
    }
}
