package com.example.app.mapper;

import com.example.app.dto.region.BureauVenteResponse;
import com.example.app.dto.region.QuartierResponse;
import com.example.app.dto.region.RegionResponse;
import com.example.app.dto.region.VilleResponse;
import com.example.app.entity.BureauVente;
import com.example.app.entity.Quartier;
import com.example.app.entity.Region;
import com.example.app.entity.Ville;

public final class RegionMapper {

    private RegionMapper() {}

    public static RegionResponse toResponse(Region region) {
        return new RegionResponse(region.getId(), region.getName());
    }

    public static VilleResponse toResponse(Ville ville) {
        return new VilleResponse(ville.getId(), ville.getName());
    }

    public static QuartierResponse toResponse(Quartier quartier) {
        return new QuartierResponse(quartier.getId(), quartier.getName());
    }

    public static BureauVenteResponse toResponse(BureauVente bv) {
        Quartier quartier = bv.getQuartier();
        Ville ville = quartier.getVille();
        return new BureauVenteResponse(
                bv.getId(),
                bv.getCode(),
                bv.getName(),
                quartier.getId(),
                quartier.getName(),
                ville.getId(),
                ville.getName()
        );
    }
}
