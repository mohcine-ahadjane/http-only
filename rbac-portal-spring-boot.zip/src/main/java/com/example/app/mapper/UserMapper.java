package com.example.app.mapper;

import com.example.app.dto.auth.UserResponse;
import com.example.app.entity.Role;
import com.example.app.entity.User;

import java.util.stream.Collectors;

public final class UserMapper {

    private UserMapper() {}

    public static UserResponse toResponse(User user) {
        return new UserResponse(
                user.getId(),
                user.getEmail(),
                user.getUsername(),
                user.getSiege(),
                user.getRoles().stream().map(Role::getName).collect(Collectors.toSet())
        );
    }
}
