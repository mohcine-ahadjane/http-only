package com.example.app.controller;

import com.example.app.dto.region.BureauVenteResponse;
import com.example.app.dto.region.QuartierResponse;
import com.example.app.dto.region.RegionResponse;
import com.example.app.dto.region.VilleResponse;
import com.example.app.security.AuthenticatedUser;
import com.example.app.service.ResponsablePortalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Endpoints du portail du responsable connecte. Permet d'alimenter le front
 * pour la selection en cascade Region (implicite) -> Ville -> Quartier -> BV,
 * ou la selection directe de tous les BV de sa region.
 */
@RestController
@RequestMapping("/api/responsable")
@RequiredArgsConstructor
@Tag(name = "Portail Responsable", description = "Listes de selection pour le responsable connecte (region, villes, quartiers, bureaux de vente)")
@SecurityRequirement(name = "cookieAuth")
public class ResponsableController {

    private final ResponsablePortalService portalService;

    @GetMapping("/region")
    @Operation(summary = "Region geree par le responsable connecte")
    public RegionResponse getMyRegion(@AuthenticationPrincipal AuthenticatedUser principal) {
        return portalService.getMyRegion(principal.id());
    }

    @GetMapping("/villes")
    @Operation(summary = "Liste des villes de la region du responsable connecte")
    public List<VilleResponse> getMyVilles(@AuthenticationPrincipal AuthenticatedUser principal) {
        return portalService.getMyVilles(principal.id());
    }

    @GetMapping("/villes/{villeId}/quartiers")
    @Operation(summary = "Liste des quartiers d'une ville de sa region (etape 2 du filtre)")
    public List<QuartierResponse> getQuartiers(@AuthenticationPrincipal AuthenticatedUser principal,
                                                @PathVariable Long villeId) {
        return portalService.getQuartiersOfVille(principal.id(), villeId);
    }

    @GetMapping("/quartiers/{quartierId}/bureaux")
    @Operation(summary = "Liste des bureaux de vente d'un quartier de sa region (etape 3 du filtre)")
    public List<BureauVenteResponse> getBureauxByQuartier(@AuthenticationPrincipal AuthenticatedUser principal,
                                                            @PathVariable Long quartierId) {
        return portalService.getBureauxOfQuartier(principal.id(), quartierId);
    }

    @GetMapping("/bureaux")
    @Operation(summary = "Selection directe: tous les bureaux de vente de la region du responsable")
    public List<BureauVenteResponse> getAllMyBureaux(@AuthenticationPrincipal AuthenticatedUser principal) {
        return portalService.getAllMyBureaux(principal.id());
    }

    @GetMapping("/bureaux/{bvId}")
    @Operation(summary = "Detail d'un bureau de vente (verifie qu'il appartient bien a sa region)")
    public BureauVenteResponse getOne(@AuthenticationPrincipal AuthenticatedUser principal,
                                       @PathVariable Long bvId) {
        return portalService.getMyBureauById(principal.id(), bvId);
    }
}
