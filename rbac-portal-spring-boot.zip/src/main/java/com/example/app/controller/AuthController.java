package com.example.app.controller;

import com.example.app.dto.auth.AuthResponse;
import com.example.app.dto.auth.LoginRequest;
import com.example.app.dto.auth.RegisterRequest;
import com.example.app.dto.auth.UserResponse;
import com.example.app.entity.User;
import com.example.app.exception.InvalidTokenException;
import com.example.app.mapper.UserMapper;
import com.example.app.security.CookieUtil;
import com.example.app.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "Authentification", description = "Inscription, connexion, rotation et deconnexion via cookies HttpOnly")
public class AuthController {

    private final AuthService authService;
    private final CookieUtil cookieUtil;

    @PostMapping("/register")
    @Operation(summary = "Creer un compte (email, username, password, siege)")
    public ResponseEntity<UserResponse> register(@Valid @RequestBody RegisterRequest request) {
        User user = authService.register(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(UserMapper.toResponse(user));
    }

    @PostMapping("/login")
    @Operation(summary = "Se connecter - positionne les cookies HttpOnly access_token et refresh_token")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request, HttpServletResponse response) {
        User user = authService.authenticate(request);
        AuthService.TokenPair tokens = authService.issueTokens(user);

        cookieUtil.addAccessTokenCookie(response, tokens.accessToken(), tokens.accessTtl());
        cookieUtil.addRefreshTokenCookie(response, tokens.refreshToken(), tokens.refreshTtl());

        return ResponseEntity.ok(new AuthResponse(UserMapper.toResponse(user), "Connexion reussie"));
    }

    @PostMapping("/refresh")
    @Operation(summary = "Rotation du token: invalide l'ancien refresh token et en emet un nouveau couple")
    public ResponseEntity<Void> refresh(HttpServletRequest request, HttpServletResponse response) {
        String refreshToken = cookieUtil.readCookie(request, CookieUtil.REFRESH_COOKIE);
        if (refreshToken == null) {
            throw new InvalidTokenException("Refresh token manquant");
        }

        AuthService.TokenPair tokens = authService.refresh(refreshToken);

        cookieUtil.addAccessTokenCookie(response, tokens.accessToken(), tokens.accessTtl());
        cookieUtil.addRefreshTokenCookie(response, tokens.refreshToken(), tokens.refreshTtl());

        return ResponseEntity.noContent().build();
    }

    @PostMapping("/logout")
    @Operation(summary = "Deconnexion - blackliste les tokens courants et efface les cookies")
    public ResponseEntity<Void> logout(HttpServletRequest request, HttpServletResponse response) {
        String accessToken = cookieUtil.readCookie(request, CookieUtil.ACCESS_COOKIE);
        String refreshToken = cookieUtil.readCookie(request, CookieUtil.REFRESH_COOKIE);

        authService.logout(accessToken, refreshToken);

        cookieUtil.clearAccessTokenCookie(response);
        cookieUtil.clearRefreshTokenCookie(response);

        return ResponseEntity.noContent().build();
    }
}
