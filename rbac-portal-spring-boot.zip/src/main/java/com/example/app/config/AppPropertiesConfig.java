package com.example.app.config;

import com.example.app.security.CookieProperties;
import com.example.app.security.JwtProperties;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationPropertiesScan(basePackageClasses = {JwtProperties.class, CookieProperties.class})
public class AppPropertiesConfig {
}
