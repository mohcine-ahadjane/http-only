package com.example.app.security;

import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;

/**
 * Garde en Redis le jti du refresh token actuellement valide pour un utilisateur
 * (un seul refresh token "actif" par utilisateur = rotation stricte).
 * Si un refresh token presente un jti qui ne correspond pas a celui stocke,
 * c'est soit un token expire/revoque, soit une tentative de reutilisation
 * (vol de token) -> on revoque alors toute la session.
 */
@Service
@RequiredArgsConstructor
public class RefreshTokenStore {

    private static final String PREFIX = "refresh:user:";

    private final StringRedisTemplate redisTemplate;

    public void store(Long userId, String jti, long ttlSeconds) {
        redisTemplate.opsForValue().set(PREFIX + userId, jti, Duration.ofSeconds(ttlSeconds));
    }

    public boolean isCurrent(Long userId, String jti) {
        String current = redisTemplate.opsForValue().get(PREFIX + userId);
        return current != null && current.equals(jti);
    }

    public void revoke(Long userId) {
        redisTemplate.delete(PREFIX + userId);
    }
}
