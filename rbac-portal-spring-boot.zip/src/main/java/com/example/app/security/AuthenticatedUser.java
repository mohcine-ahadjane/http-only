package com.example.app.security;

import java.util.List;

/**
 * Principal léger reconstruit a partir des claims du JWT (pas de requete DB
 * a chaque appel). Utilisé comme `principal` dans le SecurityContext.
 */
public record AuthenticatedUser(
        Long id,
        String username,
        List<String> roles,
        List<String> permissions
) {}
