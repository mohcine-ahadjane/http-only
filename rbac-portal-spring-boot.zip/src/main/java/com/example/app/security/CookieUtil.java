package com.example.app.security;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CookieUtil {

    public static final String ACCESS_COOKIE = "access_token";
    public static final String REFRESH_COOKIE = "refresh_token";

    private final CookieProperties cookieProperties;

    public void addAccessTokenCookie(HttpServletResponse response, String token, long maxAgeSeconds) {
        addCookie(response, ACCESS_COOKIE, token, maxAgeSeconds, "/api");
    }

    public void addRefreshTokenCookie(HttpServletResponse response, String token, long maxAgeSeconds) {
        // Refresh cookie scoped only to the refresh/logout endpoints to limit exposure
        addCookie(response, REFRESH_COOKIE, token, maxAgeSeconds, "/api/auth");
    }

    public void clearAccessTokenCookie(HttpServletResponse response) {
        addCookie(response, ACCESS_COOKIE, "", 0, "/api");
    }

    public void clearRefreshTokenCookie(HttpServletResponse response) {
        addCookie(response, REFRESH_COOKIE, "", 0, "/api/auth");
    }

    private void addCookie(HttpServletResponse response, String name, String value, long maxAgeSeconds, String path) {
        ResponseCookie.ResponseCookieBuilder builder = ResponseCookie.from(name, value)
                .httpOnly(true)
                .secure(cookieProperties.secure())
                .path(path)
                .maxAge(maxAgeSeconds)
                .sameSite(cookieProperties.sameSite());

        if (cookieProperties.domain() != null && !cookieProperties.domain().isBlank()) {
            builder.domain(cookieProperties.domain());
        }

        response.addHeader("Set-Cookie", builder.build().toString());
    }

    public String readCookie(jakarta.servlet.http.HttpServletRequest request, String name) {
        if (request.getCookies() == null) {
            return null;
        }
        for (Cookie cookie : request.getCookies()) {
            if (cookie.getName().equals(name)) {
                return cookie.getValue();
            }
        }
        return null;
    }
}
