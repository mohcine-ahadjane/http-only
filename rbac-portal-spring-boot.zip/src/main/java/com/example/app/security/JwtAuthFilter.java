package com.example.app.security;

import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final TokenBlacklistService tokenBlacklistService;
    private final CookieUtil cookieUtil;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                     @NonNull HttpServletResponse response,
                                     @NonNull FilterChain filterChain) throws ServletException, IOException {

        String token = cookieUtil.readCookie(request, CookieUtil.ACCESS_COOKIE);

        if (token != null) {
            try {
                if (!"ACCESS".equals(jwtService.getTokenType(token))) {
                    throw new JwtException("Type de token invalide");
                }
                String jti = jwtService.getJti(token);
                if (tokenBlacklistService.isBlacklisted(jti)) {
                    throw new JwtException("Token revoque");
                }
                if (jwtService.isExpired(token)) {
                    throw new JwtException("Token expire");
                }

                Long userId = jwtService.getUserId(token);
                List<String> roles = jwtService.getRoles(token);
                List<String> permissions = jwtService.getPermissions(token);

                AuthenticatedUser principal = new AuthenticatedUser(
                        userId,
                        jwtService.parseClaims(token).get("username", String.class),
                        roles,
                        permissions
                );

                List<GrantedAuthority> authorities = new ArrayList<>();
                roles.forEach(r -> authorities.add(new SimpleGrantedAuthority("ROLE_" + r)));
                permissions.forEach(p -> authorities.add(new SimpleGrantedAuthority(p)));

                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(principal, null, authorities);
                SecurityContextHolder.getContext().setAuthentication(authentication);

            } catch (JwtException | IllegalArgumentException ex) {
                SecurityContextHolder.clearContext();
            }
        }

        filterChain.doFilter(request, response);
    }
}
