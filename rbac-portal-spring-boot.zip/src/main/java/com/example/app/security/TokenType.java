package com.example.app.security;

public enum TokenType {
    ACCESS,
    REFRESH
}
