package com.example.app.repository;

import com.example.app.entity.Responsable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ResponsableRepository extends JpaRepository<Responsable, Long> {
    Optional<Responsable> findByUserId(Long userId);
}
