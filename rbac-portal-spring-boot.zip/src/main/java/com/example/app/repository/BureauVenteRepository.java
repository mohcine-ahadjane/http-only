package com.example.app.repository;

import com.example.app.entity.BureauVente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BureauVenteRepository extends JpaRepository<BureauVente, Long> {

    List<BureauVente> findByQuartierIdOrderByNameAsc(Long quartierId);

    List<BureauVente> findByQuartier_Ville_Region_IdOrderByNameAsc(Long regionId);

    boolean existsByIdAndQuartier_Ville_Region_Id(Long bvId, Long regionId);
}
