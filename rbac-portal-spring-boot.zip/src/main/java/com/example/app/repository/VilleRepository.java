package com.example.app.repository;

import com.example.app.entity.Ville;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VilleRepository extends JpaRepository<Ville, Long> {
    List<Ville> findByRegionIdOrderByNameAsc(Long regionId);
    boolean existsByIdAndRegionId(Long villeId, Long regionId);
}
