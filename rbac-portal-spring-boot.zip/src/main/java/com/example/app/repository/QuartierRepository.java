package com.example.app.repository;

import com.example.app.entity.Quartier;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuartierRepository extends JpaRepository<Quartier, Long> {
    List<Quartier> findByVilleIdOrderByNameAsc(Long villeId);
    boolean existsByIdAndVilleRegionId(Long quartierId, Long regionId);
}
