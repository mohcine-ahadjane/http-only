package com.example.app.dto.region;

public record QuartierResponse(Long id, String name) {}
