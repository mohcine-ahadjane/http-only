package com.example.app.dto.region;

public record BureauVenteResponse(
        Long id,
        String code,
        String name,
        Long quartierId,
        String quartierName,
        Long villeId,
        String villeName
) {}
