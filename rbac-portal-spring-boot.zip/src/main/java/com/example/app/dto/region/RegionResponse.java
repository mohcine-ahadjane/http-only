package com.example.app.dto.region;

public record RegionResponse(Long id, String name) {}
