package com.example.app.dto.auth;

import jakarta.validation.constraints.NotBlank;

public record LoginRequest(

        @NotBlank(message = "L'identifiant (email ou username) est obligatoire")
        String identifier,

        @NotBlank(message = "Le mot de passe est obligatoire")
        String password
) {}
