package com.example.app.dto.region;

public record VilleResponse(Long id, String name) {}
