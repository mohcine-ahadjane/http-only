package com.example.app.dto.auth;

/**
 * Les tokens ne sont jamais renvoyes dans le corps de la reponse:
 * ils sont positionnes en cookies HttpOnly. Ce DTO ne porte que
 * les infos utilisateur necessaires au front.
 */
public record AuthResponse(
        UserResponse user,
        String message
) {}
