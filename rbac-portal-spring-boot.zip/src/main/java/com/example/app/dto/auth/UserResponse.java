package com.example.app.dto.auth;

import java.util.Set;

public record UserResponse(
        Long id,
        String email,
        String username,
        String siege,
        Set<String> roles
) {}
