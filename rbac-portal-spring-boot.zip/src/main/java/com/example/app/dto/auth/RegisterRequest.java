package com.example.app.dto.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/**
 * Inscription volontairement réduite: email, username, password, siege.
 * Le rôle/permissions sont attribués côté serveur (jamais fournis par le client).
 */
public record RegisterRequest(

        @NotBlank(message = "L'email est obligatoire")
        @Email(message = "Format d'email invalide")
        String email,

        @NotBlank(message = "Le username est obligatoire")
        @Size(min = 3, max = 50, message = "Le username doit contenir entre 3 et 50 caracteres")
        @Pattern(regexp = "^[a-zA-Z0-9._-]+$", message = "Le username contient des caracteres invalides")
        String username,

        @NotBlank(message = "Le mot de passe est obligatoire")
        @Size(min = 8, max = 100, message = "Le mot de passe doit contenir au moins 8 caracteres")
        @Pattern(
                regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).+$",
                message = "Le mot de passe doit contenir au moins une majuscule, une minuscule et un chiffre"
        )
        String password,

        @NotBlank(message = "Le siege est obligatoire")
        @Size(max = 150)
        String siege
) {}
