-- Donnees de demonstration (a retirer en production)

INSERT INTO regions (name) VALUES ('Region Rabat-Sale-Kenitra'), ('Region Casablanca-Settat');

INSERT INTO villes (name, region_id)
SELECT 'Rabat', id FROM regions WHERE name = 'Region Rabat-Sale-Kenitra';
INSERT INTO villes (name, region_id)
SELECT 'Sale', id FROM regions WHERE name = 'Region Rabat-Sale-Kenitra';
INSERT INTO villes (name, region_id)
SELECT 'Casablanca', id FROM regions WHERE name = 'Region Casablanca-Settat';

INSERT INTO quartiers (name, ville_id)
SELECT 'Agdal', id FROM villes WHERE name = 'Rabat';
INSERT INTO quartiers (name, ville_id)
SELECT 'Hassan', id FROM villes WHERE name = 'Rabat';
INSERT INTO quartiers (name, ville_id)
SELECT 'Tabriquet', id FROM villes WHERE name = 'Sale';
INSERT INTO quartiers (name, ville_id)
SELECT 'Maarif', id FROM villes WHERE name = 'Casablanca';

INSERT INTO bureaux_vente (code, name, quartier_id)
SELECT 'BV-AGD-01', 'Agence Agdal Centre', id FROM quartiers WHERE name = 'Agdal';
INSERT INTO bureaux_vente (code, name, quartier_id)
SELECT 'BV-HAS-01', 'Agence Hassan Avenue', id FROM quartiers WHERE name = 'Hassan';
INSERT INTO bureaux_vente (code, name, quartier_id)
SELECT 'BV-TAB-01', 'Agence Tabriquet', id FROM quartiers WHERE name = 'Tabriquet';
INSERT INTO bureaux_vente (code, name, quartier_id)
SELECT 'BV-MAA-01', 'Agence Maarif', id FROM quartiers WHERE name = 'Maarif';

-- Compte responsable de demo (mot de passe: Responsable123 - BCrypt)
INSERT INTO users (email, username, password, siege, enabled)
VALUES (
    'responsable.demo@example.com',
    'responsable.demo',
    '$2a$10$7EqJtq98hPqEX7fNZaFWoOe6X9z6.OnPxV1aHl4U8U.NQPe7TyZ8a',
    'Siege Rabat',
    true
);

INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id FROM users u, roles r
WHERE u.username = 'responsable.demo' AND r.name = 'RESPONSABLE';

INSERT INTO responsables (user_id, region_id)
SELECT u.id, reg.id FROM users u, regions reg
WHERE u.username = 'responsable.demo' AND reg.name = 'Region Rabat-Sale-Kenitra';
