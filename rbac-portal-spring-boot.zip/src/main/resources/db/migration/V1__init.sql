-- ==========================================================
-- RBAC core tables
-- ==========================================================
CREATE TABLE permissions (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255)
);

CREATE TABLE roles (
    id          BIGSERIAL PRIMARY KEY,
    name        VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255)
);

CREATE TABLE role_permissions (
    role_id       BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id BIGINT NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE users (
    id         BIGSERIAL PRIMARY KEY,
    email      VARCHAR(150) NOT NULL UNIQUE,
    username   VARCHAR(80)  NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    siege      VARCHAR(150) NOT NULL,
    enabled    BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP    NOT NULL DEFAULT now(),
    updated_at TIMESTAMP    NOT NULL DEFAULT now()
);

CREATE TABLE user_roles (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id BIGINT NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

-- ==========================================================
-- Geographic / business hierarchy
-- Region -> Ville -> Quartier -> BureauVente
-- Region 1..N Responsable (same role)
-- ==========================================================
CREATE TABLE regions (
    id   BIGSERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE villes (
    id        BIGSERIAL PRIMARY KEY,
    name      VARCHAR(100) NOT NULL,
    region_id BIGINT NOT NULL REFERENCES regions(id) ON DELETE CASCADE,
    UNIQUE (name, region_id)
);

CREATE TABLE quartiers (
    id       BIGSERIAL PRIMARY KEY,
    name     VARCHAR(100) NOT NULL,
    ville_id BIGINT NOT NULL REFERENCES villes(id) ON DELETE CASCADE,
    UNIQUE (name, ville_id)
);

CREATE TABLE bureaux_vente (
    id           BIGSERIAL PRIMARY KEY,
    code         VARCHAR(30) NOT NULL UNIQUE,
    name         VARCHAR(120) NOT NULL,
    quartier_id  BIGINT NOT NULL REFERENCES quartiers(id) ON DELETE CASCADE
);

CREATE TABLE responsables (
    id        BIGSERIAL PRIMARY KEY,
    user_id   BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    region_id BIGINT NOT NULL REFERENCES regions(id) ON DELETE CASCADE
);

CREATE INDEX idx_villes_region ON villes(region_id);
CREATE INDEX idx_quartiers_ville ON quartiers(ville_id);
CREATE INDEX idx_bv_quartier ON bureaux_vente(quartier_id);
CREATE INDEX idx_responsables_region ON responsables(region_id);

-- ==========================================================
-- Seed RBAC data
-- ==========================================================
INSERT INTO permissions (name, description) VALUES
    ('BV_READ',        'Consulter les bureaux de vente'),
    ('REGION_READ',     'Consulter les regions'),
    ('USER_READ',       'Consulter les utilisateurs'),
    ('USER_MANAGE',     'Gerer les utilisateurs');

INSERT INTO roles (name, description) VALUES
    ('ADMIN',        'Administrateur de la plateforme'),
    ('RESPONSABLE',  'Responsable regional gerant les bureaux de vente'),
    ('USER',         'Utilisateur standard');

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p WHERE r.name = 'ADMIN';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.name = 'RESPONSABLE' AND p.name IN ('BV_READ', 'REGION_READ');
